package com.trademan.discoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeManDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
