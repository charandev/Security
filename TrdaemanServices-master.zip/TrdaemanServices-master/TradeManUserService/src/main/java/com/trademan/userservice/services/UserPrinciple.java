package com.trademan.userservice.services;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.trademan.userservice.entity.User;

public class UserPrinciple implements UserDetails {

	private static final long serialVersionUID = 1L;

	private String name;

	private String mobileNumber;

	private String email;

	@JsonIgnore
	private String uId;

	private Collection<? extends GrantedAuthority> authorities;

	public UserPrinciple(String name, String mobileNumber, String email, String uId,
			Collection<? extends GrantedAuthority> authorities) {

		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.uId = uId;
		this.authorities = authorities;
	}

	public static UserPrinciple build(User user) {
		List<GrantedAuthority> authorities = user.getRoles().stream()
				.map(role -> new SimpleGrantedAuthority(role.getName().name())).collect(Collectors.toList());

		return new UserPrinciple(user.getName(), user.getMobileNumber(), user.getEmail(), user.getUId(), authorities);
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	@Override
	public String getUsername() {
		return mobileNumber;
	}

	@Override
	public String getPassword() {
		return uId;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}