package com.trademan.userservice.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("users")
public class User {

	private String name;
	@Id
	private String mobileNumber;

	private String email;

	private String uId;

	private Location location;

	private Date signUpDate;

	private Date lastLoginTime;

	private BusinessProfile businessProfile;

	private List<Commodity> commodities;

	private List<BusinessTag> businessTags;

	private List<User> subscribers;

	public List<BusinessTag> getBusinessTags() {

		return businessTags;
	}

	public List<User> getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(List<User> subscribers) {
		this.subscribers = subscribers;
	}

	public void setBusinessTags(List<BusinessTag> businessTags) {
		this.businessTags = businessTags;
	}

	private Set<Role> roles = new HashSet<>();

	public User() {
	}

	public User(String name, String mobileNumber, String email, String uId, Date signUpDate, Date lastLoginTime) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.uId = uId;
		this.signUpDate = signUpDate;
		this.lastLoginTime = lastLoginTime;
	}

	public BusinessProfile getBusinessProfile() {
		return businessProfile;
	}

	public List<Commodity> getCommodities() {
		return commodities;
	}

	public String getEmail() {
		return email;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public Location getLocation() {
		return location;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getName() {
		return name;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public Date getSignUpDate() {
		return signUpDate;
	}

	public String getuId() {
		return uId;
	}

	public String getUId() {
		return uId;
	}

	public void setBusinessProfile(BusinessProfile businessProfile) {
		this.businessProfile = businessProfile;
	}

	public void setCommodities(List<Commodity> commodities) {
		this.commodities = commodities;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public void setSignUpDate(Date signUpDate) {
		this.signUpDate = signUpDate;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public void setUId(String uId) {
		this.uId = uId;
	}

}