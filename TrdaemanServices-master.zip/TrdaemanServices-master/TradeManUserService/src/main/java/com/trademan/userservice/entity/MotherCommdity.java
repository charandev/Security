package com.trademan.userservice.entity;

public enum MotherCommdity {
	
	InternationProduct,Vegetable

}
