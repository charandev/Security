package com.trademan.userservice.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("businesstag")
public class BusinessTag {

	@Id
	private String tagName;
	private TagFamily tagFamily;

	public BusinessTag() {

	}

	public BusinessTag(String tagName, TagFamily tagFamily) {
		this.tagName = tagName;
		this.tagFamily = tagFamily;
	}

	public TagFamily getTagFamily() {
		return tagFamily;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagFamily(TagFamily tagFamily) {
		this.tagFamily = tagFamily;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}
