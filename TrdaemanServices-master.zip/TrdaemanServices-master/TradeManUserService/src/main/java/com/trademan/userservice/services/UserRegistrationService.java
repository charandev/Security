package com.trademan.userservice.services;

import java.util.List;

import com.trademan.userservice.dto.BusinessProfileDto;
import com.trademan.userservice.dto.FarmerProductsDto;
import com.trademan.userservice.entity.AllUsers;
import com.trademan.userservice.entity.Role;
import com.trademan.userservice.entity.Subscription;
import com.trademan.userservice.entity.User;
import com.trademan.userservice.exception.UserNotExistsException;
import com.trademan.userservice.exception.UserRegistrationException;
import com.trademan.userservice.message.request.SignUpForm;

public interface UserRegistrationService {

	/**
	 * @param signUpRequest
	 * @return
	 * @throws UserRegistrationException
	 */
	String addUser(SignUpForm signUpRequest) throws UserRegistrationException;

	Role addRole(Role role);

	User getUser(String mobileNumber) throws UserNotExistsException;

	Long deleteUser(String mobileNumber) throws UserNotExistsException;

	User addBusinessProfile(BusinessProfileDto businessProfileDto) throws UserRegistrationException;

	User updateSubscription(String mobileNumber, Subscription subscription) throws UserNotExistsException;

	User addProducts(String mobileNumber, FarmerProductsDto farmerProductDto) throws UserNotExistsException;

	User updateUser(User user);

	List<AllUsers> getAllUsers();

	User addSubscriber(String mobileNumber, User subscriber) throws UserNotExistsException;

	List<User> getSubscribers(String mobileNumber) throws UserNotExistsException;

	User removeSubscriber(String mobileNumber, User subscriber) throws UserNotExistsException;

}
