package com.trademan.userservice.dto;

import java.util.List;

import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.entity.Commodity;
import com.trademan.userservice.entity.Location;

public class BusinessProfileDto {
	private String mobileNumber;

	private String userName;
	private String businessName;

	private String userDesignation;

	private Location location;
	private String businessType;

	private List<Commodity> commodities;

	private List<BusinessTag> businessTags;

	public BusinessProfileDto() {

	}

	public BusinessProfileDto(String userName, String businessName, String userDesignation, String userLocation,
			String locationLatitude, String locationLongitude, List<Commodity> commodities) {

		this.userName = userName;
		this.businessName = businessName;
		this.userDesignation = userDesignation;
		this.commodities = commodities;
	}

	public String getBusinessName() {
		return businessName;
	}

	public List<BusinessTag> getBusinessTags() {
		return businessTags;
	}

	public String getBusinessType() {
		return businessType;
	}

	public List<Commodity> getCommodities() {
		return commodities;
	}

	public Location getLocation() {
		return location;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getUserDesignation() {
		return userDesignation;
	}

	public String getUserName() {
		return userName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public void setBusinessTags(List<BusinessTag> businessTags) {
		this.businessTags = businessTags;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public void setCommodities(List<Commodity> commodities) {
		this.commodities = commodities;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setUserDesignation(String userDesignation) {
		this.userDesignation = userDesignation;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
