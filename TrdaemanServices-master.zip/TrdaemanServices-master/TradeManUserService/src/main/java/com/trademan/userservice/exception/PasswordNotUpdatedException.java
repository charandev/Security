package com.trademan.userservice.exception;

public class PasswordNotUpdatedException extends UserRegistrationException {

	public PasswordNotUpdatedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PasswordNotUpdatedException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public PasswordNotUpdatedException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public PasswordNotUpdatedException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PasswordNotUpdatedException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
