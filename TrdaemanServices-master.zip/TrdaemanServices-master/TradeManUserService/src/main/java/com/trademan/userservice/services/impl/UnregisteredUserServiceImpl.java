package com.trademan.userservice.services.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.trademan.userservice.entity.BusinessProfile;
import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.entity.Commodity;
import com.trademan.userservice.entity.Location;
import com.trademan.userservice.entity.Subscription;
import com.trademan.userservice.entity.SubscriptionPlan;
import com.trademan.userservice.entity.UnregisteredUser;
import com.trademan.userservice.repository.BusinessTagRepository;
import com.trademan.userservice.repository.CommodityRepository;
import com.trademan.userservice.repository.LocationRepository;
import com.trademan.userservice.repository.UnregisteredUserRepository;
import com.trademan.userservice.services.UnregisteredUserService;

@Service
public class UnregisteredUserServiceImpl implements UnregisteredUserService {

	@Autowired
	private UnregisteredUserRepository unregisteredUserRepo;

	@Autowired
	private LocationRepository locationRepo;

	@Autowired
	private CommodityRepository commodityRepo;

	@Autowired
	private BusinessTagRepository tagRepo;

	@Override
	public UnregisteredUser addUnregisteredUser(UnregisteredUser unregisteredUSer) {
		unregisteredUSer.setSignUpDate(new Date(System.currentTimeMillis()));

		return unregisteredUserRepo.save(unregisteredUSer);
	}

	@Override
	public List<UnregisteredUser> getAllUnregisteredUSer() {

		return unregisteredUserRepo.findAll();
	}

	@Override
	public String addUsersFromExcel(MultipartFile file) {
		File excelFile = new File(file.getOriginalFilename());
		XSSFWorkbook workbook = null;
		try {
			excelFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(excelFile);
			fos.write(file.getBytes());
			fos.close();
			FileInputStream fileIp = new FileInputStream(excelFile);
			workbook = new XSSFWorkbook(fileIp);

			XSSFSheet sheet = workbook.getSheetAt(0);
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				UnregisteredUser unregisteredUser = new UnregisteredUser();
				unregisteredUser.setName(row.getCell(0).getStringCellValue());
				unregisteredUser.setMobileNumber(String.valueOf(row.getCell(1).getNumericCellValue()));
				unregisteredUser.setEmail(row.getCell(2).getStringCellValue());
				Location location = locationRepo.findByDisplayName(row.getCell(3).getStringCellValue());
				unregisteredUser.setLocation(location);
				BusinessProfile businessProfile = new BusinessProfile();
				businessProfile.setBusinessName(row.getCell(4).getStringCellValue());
				businessProfile.setUserDesignation(row.getCell(5).getStringCellValue());
				businessProfile.setBusinessType(row.getCell(6).getStringCellValue());
				Subscription subscription = new Subscription();
				subscription.setSubscribed(row.getCell(7).getBooleanCellValue());
				if (row.getCell(8).getStringCellValue().equals("TRADEMAN_SILVER")) {
					subscription.setSubscriptionPlan(SubscriptionPlan.TRADEMAN_SILVER);
				}
				if (row.getCell(8).getStringCellValue().equals("TRADEMAN_GOLD")) {
					subscription.setSubscriptionPlan(SubscriptionPlan.TRADEMAN_GOLD);
				}
				if (row.getCell(8).getStringCellValue().equals("TRADEMAN_DIAMOND")) {
					subscription.setSubscriptionPlan(SubscriptionPlan.TRADEMAN_DIAMOND);
				}
				if (row.getCell(8).getStringCellValue().equals("TRADEMAN_PLATINUM")) {
					subscription.setSubscriptionPlan(SubscriptionPlan.TRADEMAN_PLATINUM);
				}

				businessProfile.setSubscription(subscription);
				unregisteredUser.setBusinessProfile(businessProfile);
				unregisteredUser.setSignUpDate(new Date(System.currentTimeMillis()));
				List<Commodity> commodities = new ArrayList<Commodity>();
				String[] commoditiesSubString = row.getCell(9).getStringCellValue().split(",");
				for (String commodityName : commoditiesSubString) {
					commodities.add(commodityRepo.findByName(commodityName));

				}
				unregisteredUser.setCommodities(commodities);
				List<BusinessTag> businessTags = new ArrayList<BusinessTag>();
				String[] tagsSubString = row.getCell(10).getStringCellValue().split(",");
				for (String tagName : tagsSubString) {
					businessTags.add(tagRepo.findByTagName(tagName));
				}
				unregisteredUser.setBusinessTags(businessTags);

				unregisteredUser.setRole(row.getCell(11).getStringCellValue());
				unregisteredUserRepo.save(unregisteredUser);

			}
			return "Records inserted successfully";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Unsuccessful";

	}

	@Override
	public UnregisteredUser updateUser(UnregisteredUser user) {
		return unregisteredUserRepo.save(user);
	}

}
