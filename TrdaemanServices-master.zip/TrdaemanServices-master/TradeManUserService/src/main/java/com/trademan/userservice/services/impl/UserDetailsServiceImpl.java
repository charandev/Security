package com.trademan.userservice.services.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trademan.userservice.entity.User;
import com.trademan.userservice.repository.UserRepository;
import com.trademan.userservice.services.UserPrinciple;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String mobileNumber) throws UsernameNotFoundException {

		User user = userRepository.findByMobileNumber(mobileNumber).orElseThrow(
				() -> new UsernameNotFoundException("User Not Found with -> Mobile Number : " + mobileNumber));
		user.setLastLoginTime(new Date(System.currentTimeMillis()));

		userRepository.save(user);
		return UserPrinciple.build(user);
	}
}