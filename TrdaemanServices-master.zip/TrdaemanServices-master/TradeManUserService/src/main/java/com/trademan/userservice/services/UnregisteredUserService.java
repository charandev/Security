package com.trademan.userservice.services;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.entity.UnregisteredUser;

@Service
public interface UnregisteredUserService {
	public UnregisteredUser addUnregisteredUser(UnregisteredUser unregisteredUSer);

	public List<UnregisteredUser> getAllUnregisteredUSer();

	public String addUsersFromExcel(MultipartFile file);

	public UnregisteredUser updateUser(UnregisteredUser user);
}
