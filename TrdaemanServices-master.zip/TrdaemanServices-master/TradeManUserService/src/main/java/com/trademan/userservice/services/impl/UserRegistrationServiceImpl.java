package com.trademan.userservice.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.trademan.userservice.dto.BusinessProfileDto;
import com.trademan.userservice.dto.FarmerProductsDto;
import com.trademan.userservice.entity.AllUsers;
import com.trademan.userservice.entity.BusinessProfile;
import com.trademan.userservice.entity.Role;
import com.trademan.userservice.entity.RoleName;
import com.trademan.userservice.entity.Subscription;
import com.trademan.userservice.entity.UnregisteredUser;
import com.trademan.userservice.entity.User;
import com.trademan.userservice.exception.EmailAlreadyExistsException;
import com.trademan.userservice.exception.UserNameAlreadyExistException;
import com.trademan.userservice.exception.UserNotExistsException;
import com.trademan.userservice.exception.UserRegistrationException;
import com.trademan.userservice.message.request.SignUpForm;
import com.trademan.userservice.repository.RoleRepository;
import com.trademan.userservice.repository.UserRepository;
import com.trademan.userservice.services.UnregisteredUserService;
import com.trademan.userservice.services.UserRegistrationService;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UnregisteredUserService unregisteredUserService;

	@Override
	public String addUser(SignUpForm signUpRequest) throws UserRegistrationException {
		if (userRepository.existsByMobileNumber(signUpRequest.getMobileNumber())) {
			throw new UserNameAlreadyExistException(
					"Fail -> User already registered with the mobile number please login");
		}
		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			throw new EmailAlreadyExistsException("Fail -> Email is already in use!");
		}
		User user = new User(signUpRequest.getName(), signUpRequest.getMobileNumber(), signUpRequest.getEmail(),
				encoder.encode(signUpRequest.getuId()), new Date(System.currentTimeMillis()),
				new Date(System.currentTimeMillis()));
//		System.out.println(signUpRequest.getLocation().getCity());
		user.setLocation(signUpRequest.getLocation());
		Set<String> strRoles = signUpRequest.getRoles();
		Set<Role> roles = new HashSet<>();

		strRoles.forEach(role -> {
			switch (role) {
			case "admin":
				Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(adminRole);

				break;
			case "farmer":
				Role farmerRole = roleRepository.findByName(RoleName.ROLE_FARMER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(farmerRole);

				break;
			case "trader":
				Role traderRole = roleRepository.findByName(RoleName.ROLE_TRADER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(traderRole);

				break;
			case "broker":
				Role brokerRole = roleRepository.findByName(RoleName.ROLE_BROKER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(brokerRole);

				break;
			default:
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(userRole);
			}
		});

		user.setRoles(roles);
		if (userRepository.save(user) != null) {

			return "User Registered successfully!";
		}
		return "unsucessfully";

	}

	@Override
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public Role addRole(Role role) {

		return roleRepository.save(role);
	}

	@Override
	public User getUser(String mobileNumber) throws UserNotExistsException {
		if (!(userRepository.existsByMobileNumber(mobileNumber))) {
			throw new UserNotExistsException("user Not exists");
		}
		User user = userRepository.findByMobileNumber(mobileNumber).orElseThrow(
				() -> new UsernameNotFoundException("User Not Found with -> Mobile Number : " + mobileNumber));
		return user;
	}

	@Override
	public Long deleteUser(String mobileNumber) throws UserNotExistsException {
		if (!(userRepository.existsByMobileNumber(mobileNumber))) {
			throw new UserNotExistsException("user Not exists");
		}
		return userRepository.deleteByMobileNumber(mobileNumber);

	}

	@Override
	public User addBusinessProfile(BusinessProfileDto businessProfileDto) throws UserRegistrationException {

		User user = userRepository.findByMobileNumber(businessProfileDto.getMobileNumber())
				.orElseThrow(() -> new UserNotExistsException(
						"User not exists with mobile number -> " + businessProfileDto.getMobileNumber()));

		user.setName(businessProfileDto.getUserName());
		user.setLocation(businessProfileDto.getLocation());
		user.setCommodities(businessProfileDto.getCommodities());
		user.setBusinessTags(businessProfileDto.getBusinessTags());
		BusinessProfile businessProfile = new BusinessProfile();
		businessProfile.setBusinessName(businessProfileDto.getBusinessName());
		businessProfile.setBusinessType(businessProfileDto.getBusinessType());
		businessProfile.setUserDesignation(businessProfileDto.getUserDesignation());
		user.setBusinessProfile(businessProfile);
		return userRepository.save(user);

	}

	@Override
	public User updateSubscription(String mobileNumber, Subscription subscription) throws UserNotExistsException {
		User user = userRepository.findByMobileNumber(mobileNumber)
				.orElseThrow(() -> new UserNotExistsException("User not exists with mobile number -> " + mobileNumber));

		BusinessProfile businessProfile = new BusinessProfile(user.getBusinessProfile().getBusinessName(),
				user.getBusinessProfile().getUserDesignation(), user.getBusinessProfile().getBusinessType(),
				subscription);
		user.setBusinessProfile(businessProfile);

		return userRepository.save(user);
	}

	@Override
	public User addProducts(String mobileNumber, FarmerProductsDto farmerProductDto) throws UserNotExistsException {
		User user = userRepository.findByMobileNumber(mobileNumber)
				.orElseThrow(() -> new UserNotExistsException("User not exists with mobile number -> " + mobileNumber));
		user.setCommodities(farmerProductDto.getCommodities());
		user.setBusinessTags(farmerProductDto.getBusinessTags());
		return userRepository.save(user);
	}

	@Override
	public List<AllUsers> getAllUsers() {

		List<AllUsers> allUsers = new ArrayList<AllUsers>();
		List<User> users = userRepository.findAll();
		users.forEach(user -> {
			AllUsers allUser = new AllUsers();
			allUser.setName(user.getName());
			allUser.setBusinessProfile(user.getBusinessProfile());
			allUser.setBusinessTags(user.getBusinessTags());
			allUser.setCommodities(user.getCommodities());
			allUser.setEmail(user.getEmail());
			allUser.setLocation(user.getLocation());
			allUser.setMobileNumber(user.getMobileNumber());
			allUser.setRoles(user.getRoles());
			allUser.setSignUpDate(user.getSignUpDate());
			allUser.setRegistered(true);
			allUsers.add(allUser);
		});
		List<UnregisteredUser> unregisteredUsers = unregisteredUserService.getAllUnregisteredUSer();
		unregisteredUsers.forEach(user -> {
			AllUsers allUser = new AllUsers();
			allUser.setName(user.getName());
			allUser.setBusinessProfile(user.getBusinessProfile());
			allUser.setBusinessTags(user.getBusinessTags());
			allUser.setCommodities(user.getCommodities());
			allUser.setEmail(user.getEmail());
			allUser.setLocation(user.getLocation());
			allUser.setMobileNumber(user.getMobileNumber());
			allUser.setRole(user.getRole());
			allUser.setSignUpDate(user.getSignUpDate());
			allUser.setRegistered(false);
			allUsers.add(allUser);
		});
		return allUsers;

	}

	@Override
	public User addSubscriber(String mobileNumber, User subscriber) throws UserNotExistsException {
		User user = userRepository.findByMobileNumber(mobileNumber)
				.orElseThrow(() -> new UserNotExistsException("User not exists with mobile number -> " + mobileNumber));
		List<User> subscribers = new ArrayList<User>();
		if (user.getSubscribers() == null) {

			subscribers.add(subscriber);
		} else {
			subscribers = user.getSubscribers();
			subscribers.add(subscriber);
		}

		user.setSubscribers(subscribers);
		return userRepository.save(user);

	}

	@Override
	public List<User> getSubscribers(String mobileNumber) throws UserNotExistsException {

		User user = userRepository.findByMobileNumber(mobileNumber)
				.orElseThrow(() -> new UserNotExistsException("User not exists with mobile number -> " + mobileNumber));
		return user.getSubscribers();
	}

	@Override
	public User removeSubscriber(String mobileNumber, User subscriber) throws UserNotExistsException {
		User user = userRepository.findByMobileNumber(mobileNumber)
				.orElseThrow(() -> new UserNotExistsException("User not exists with mobile number -> " + mobileNumber));
		List<User> subscribers = user.getSubscribers();

		for (int i = 0; i < subscribers.size(); i++) {
			if (subscribers.get(i).getMobileNumber().equals(subscriber.getMobileNumber())) {
				subscribers.remove(i);
				break;
			}
		}
		user.setSubscribers(subscribers);
		return userRepository.save(user);
	}


}
