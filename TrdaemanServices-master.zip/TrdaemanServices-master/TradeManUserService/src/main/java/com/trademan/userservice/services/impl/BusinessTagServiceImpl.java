package com.trademan.userservice.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.exception.UnableToDeleteTagException;
import com.trademan.userservice.repository.BusinessTagRepository;
import com.trademan.userservice.services.BusinessTagService;

@Service
public class BusinessTagServiceImpl implements BusinessTagService {

	@Autowired
	private BusinessTagRepository tagRepo;

	@Override
	public BusinessTag addBusinessTag(BusinessTag businessTag) {
		return tagRepo.save(businessTag);
	}

	@Override
	public List<BusinessTag> getAllBusinessTags() {
		return tagRepo.findAll();
	}

	@Override
	public String deleteTag(String tagName) throws UnableToDeleteTagException {
		try {
			tagRepo.deleteByTagName(tagName);
			return tagName;
		} catch (Exception e) {
			throw new UnableToDeleteTagException("Unable to delete Tag", e);
		}
	}

}
