package com.trademan.userservice.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.Commodity;
import com.trademan.userservice.exception.UnableToDeleteCommodityException;
import com.trademan.userservice.repository.CommodityRepository;
import com.trademan.userservice.services.CommodityService;

@Service
public class CommodityServiceImpl implements CommodityService {

	@Autowired
	private CommodityRepository commodityRepo;

	@Override
	public Commodity addCommodity(Commodity commodity) {
		return commodityRepo.save(commodity);
	}

	@Override
	public List<Commodity> getAllCommodities() {
		return commodityRepo.findAll();
	}

	@Override
	public String deleteCommodity(String commodityName) throws UnableToDeleteCommodityException {
		try {
			commodityRepo.deleteByName(commodityName);
			return commodityName;
		} catch (Exception e) {
			throw new UnableToDeleteCommodityException("unable to delete commodity", e);
		}

	}

}
