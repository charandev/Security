package com.trademan.userservice.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.Commodity;
import com.trademan.userservice.exception.UnableToDeleteCommodityException;

@Service
public interface CommodityService {

	public Commodity addCommodity(Commodity commodity);

	public List<Commodity> getAllCommodities();

	public String deleteCommodity(String commodityName) throws UnableToDeleteCommodityException;

}
