package com.trademan.userservice.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("commodity")
public class Commodity {
	@Id
	private String name;
	private MotherCommdity motherCommodity;

	public Commodity() {

	}

	public Commodity(String name, MotherCommdity motherCommodity) {
		this.name = name;
		this.motherCommodity = motherCommodity;
	}

	public MotherCommdity getMotherCommodity() {
		return motherCommodity;
	}

	public String getName() {
		return name;
	}

	public void setMotherCommodity(MotherCommdity motherCommodity) {
		this.motherCommodity = motherCommodity;
	}

	public void setName(String name) {
		this.name = name;
	}

}
