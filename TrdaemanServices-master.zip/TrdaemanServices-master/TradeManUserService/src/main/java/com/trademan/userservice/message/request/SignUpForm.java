package com.trademan.userservice.message.request;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.trademan.userservice.entity.Location;

public class SignUpForm {

	private String name;

	private String mobileNumber;

	private String email;

	private String uId;

	private Location location;
	private Date signUpDate;

	private Date lastLoginTime;

	private Set<String> roles = new HashSet<>();

	public String getuId() {
		return uId;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public Date getSignUpDate() {
		return signUpDate;
	}

	public void setSignUpDate(Date signUpDate) {
		this.signUpDate = signUpDate;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public SignUpForm() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUId() {
		return uId;
	}

	public void setUId(String uId) {
		this.uId = uId;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	public SignUpForm(String name, String mobileNumber, String email, String uId, Date signUpDate, Date lastLoginTime,
			Set<String> roles) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.uId = uId;

		this.signUpDate = signUpDate;
		this.lastLoginTime = lastLoginTime;
		this.roles = roles;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

}
