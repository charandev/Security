package com.trademan.userservice.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.Location;
import com.trademan.userservice.exception.UnableToDeleteLocationException;
import com.trademan.userservice.repository.LocationRepository;
import com.trademan.userservice.services.LocationService;

@Service
public class LocationServiceImpl implements LocationService {

	@Autowired
	private LocationRepository locationRepo;

	@Override
	public Location addLocation(Location location) {
		if (location.getId() == null) {
			location.setId("Amo_" + location.getTown() + "_" + location.getDistrict() + "_" + location.getState());
		}

		return locationRepo.save(location);
	}

	@Override
	public List<Location> getAllLocations() {
		return locationRepo.findAll();
	}

	@Override
	public String deleteLocation(String displayName) throws UnableToDeleteLocationException {
		try {
			locationRepo.deleteByDisplayName(displayName);
			return displayName;

		} catch (Exception e) {
			throw new UnableToDeleteLocationException("Unable to delete Location", e);
		}
	}

}
