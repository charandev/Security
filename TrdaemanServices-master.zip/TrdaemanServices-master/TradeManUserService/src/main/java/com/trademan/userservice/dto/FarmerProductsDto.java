package com.trademan.userservice.dto;

import java.util.List;

import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.entity.Commodity;

public class FarmerProductsDto {

	private List<Commodity> commodities;
	private List<BusinessTag> businessTags;

	public FarmerProductsDto() {
	}

	public FarmerProductsDto(List<Commodity> commodities, List<BusinessTag> businessTags) {
		this.commodities = commodities;
		this.businessTags = businessTags;
	}

	public List<BusinessTag> getBusinessTags() {
		return businessTags;
	}

	public List<Commodity> getCommodities() {
		return commodities;
	}

	public void setBusinessTags(List<BusinessTag> businessTags) {
		this.businessTags = businessTags;
	}

	public void setCommodities(List<Commodity> commodities) {
		this.commodities = commodities;
	}

}
