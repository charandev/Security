package com.trademan.userservice.entity;

public class Subscriber {
	private String mobileNumber;
	private String name;
	private String role;
	private String email;

	public Subscriber(String mobileNumber, String name, String role, String email) {
		this.mobileNumber = mobileNumber;
		this.name = name;
		this.role = role;
		this.email = email;
	}

	public Subscriber() {
	}

	public String getEmail() {
		return email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
