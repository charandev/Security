package com.trademan.userservice.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.trademan.userservice.entity.User;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
	Optional<User> findByMobileNumber(String mobileNumber);

	Boolean existsByMobileNumber(String mobileNumber);

	Boolean existsByEmail(String email);

	Optional<User> findByEmail(String email);
	
	Long deleteByMobileNumber(String mobileNumber);

}