package com.trademan.userservice.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AllUsers {
	private boolean isRegistered;
	private String name;
	private String mobileNumber;
	private String email;

	private Location location;

	private Date signUpDate;
	private BusinessProfile businessProfile;
	private List<Commodity> commodities;
	private String role;
	private List<BusinessTag> businessTags;
	private Set<Role> roles = new HashSet<>();
	public AllUsers() {
		
	}
	public AllUsers(boolean isRegistered, String name, String mobileNumber, String email, Location location,
			Date signUpDate, BusinessProfile businessProfile, List<Commodity> commodities, String role,
			List<BusinessTag> businessTags, Set<Role> roles) {
		this.isRegistered = isRegistered;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.location = location;
		this.signUpDate = signUpDate;
		this.businessProfile = businessProfile;
		this.commodities = commodities;
		this.role = role;
		this.businessTags = businessTags;
		this.roles = roles;
	}

	public BusinessProfile getBusinessProfile() {
		return businessProfile;
	}

	public List<BusinessTag> getBusinessTags() {
		return businessTags;
	}

	public List<Commodity> getCommodities() {
		return commodities;
	}

	public String getEmail() {
		return email;
	}

	public Location getLocation() {
		return location;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public Date getSignUpDate() {
		return signUpDate;
	}

	public boolean isRegistered() {
		return isRegistered;
	}

	public void setBusinessProfile(BusinessProfile businessProfile) {
		this.businessProfile = businessProfile;
	}

	public void setBusinessTags(List<BusinessTag> businessTags) {
		this.businessTags = businessTags;
	}

	public void setCommodities(List<Commodity> commodities) {
		this.commodities = commodities;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRegistered(boolean isRegistered) {
		this.isRegistered = isRegistered;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public void setSignUpDate(Date signUpDate) {
		this.signUpDate = signUpDate;
	}
}
