package com.trademan.userservice.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("roles")
public class Role {

	private Long id;

	private RoleName name;

	public Role() {
	}

	public Role(RoleName name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RoleName getName() {
		return name;
	}

	public void setName(RoleName name) {
		this.name = name;
	}
}