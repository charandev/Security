package com.trademan.userservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trademan.userservice.entity.Location;
import com.trademan.userservice.exception.UnableToDeleteCommodityException;
import com.trademan.userservice.exception.UnableToDeleteLocationException;
import com.trademan.userservice.services.LocationService;

@RestController
@CrossOrigin
@RequestMapping("/location")
public class LocationController {

	@Autowired
	private LocationService locationService;

	@PostMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> addLocation(@RequestBody Location location) {

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("body", locationService.addLocation(location));

		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@GetMapping
	public ResponseEntity<Map<String, Object>> getAllLocations() {

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("body", locationService.getAllLocations());
//		System.out.println(locationService.getAllLocations());
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@DeleteMapping("/{displayName}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> deleteCommodity(@PathVariable String displayName)
			throws UnableToDeleteLocationException {
		System.out.println(displayName);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("body", locationService.deleteLocation(displayName));

		return ResponseEntity.status(HttpStatus.ACCEPTED).body(result);
	}

}
