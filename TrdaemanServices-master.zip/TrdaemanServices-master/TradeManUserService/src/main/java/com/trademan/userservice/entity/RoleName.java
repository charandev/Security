package com.trademan.userservice.entity;
public enum RoleName {
	ROLE_USER, ROLE_FARMER, ROLE_TRADER, ROLE_BROKER, ROLE_ADMIN
}