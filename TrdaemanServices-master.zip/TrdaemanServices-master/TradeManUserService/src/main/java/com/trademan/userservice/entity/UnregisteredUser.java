package com.trademan.userservice.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("unregisteredusers")
public class UnregisteredUser {

	private String name;
	@Id
	private String mobileNumber;

	private String email;

	private Location location;

	private Date signUpDate;

	private BusinessProfile businessProfile;

	private List<Commodity> commodities;

	private String role;

	private List<BusinessTag> businessTags;

	public UnregisteredUser() {
	}

	public UnregisteredUser(String name, String mobileNumber, String email, Date signUpDate, Date lastLoginTime) {
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.signUpDate = signUpDate;
	}

	public BusinessProfile getBusinessProfile() {
		return businessProfile;
	}

	public List<BusinessTag> getBusinessTags() {
		return businessTags;
	}

	public List<Commodity> getCommodities() {
		return commodities;
	}

	public String getEmail() {
		return email;
	}

	public Location getLocation() {
		return location;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getName() {
		return name;
	}

	public Date getSignUpDate() {
		return signUpDate;
	}

	public void setBusinessProfile(BusinessProfile businessProfile) {
		this.businessProfile = businessProfile;
	}

	public void setBusinessTags(List<BusinessTag> businessTags) {
		this.businessTags = businessTags;
	}

	public void setCommodities(List<Commodity> commodities) {
		this.commodities = commodities;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSignUpDate(Date signUpDate) {
		this.signUpDate = signUpDate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
