package com.trademan.userservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trademan.userservice.dto.BusinessProfileDto;
import com.trademan.userservice.dto.FarmerProductsDto;
import com.trademan.userservice.entity.Role;
import com.trademan.userservice.entity.Subscription;
import com.trademan.userservice.entity.User;
import com.trademan.userservice.exception.UserNotExistsException;
import com.trademan.userservice.exception.UserRegistrationException;
import com.trademan.userservice.message.request.LoginForm;
import com.trademan.userservice.message.request.SignUpForm;
import com.trademan.userservice.message.response.JwtResponse;
import com.trademan.userservice.message.response.ResponseMessage;
import com.trademan.userservice.security.jwt.JwtProvider;
import com.trademan.userservice.services.UserRegistrationService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/user")
public class AuthRestAPIs {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRegistrationService userRegistrationService;

	@Autowired
	JwtProvider jwtProvider;

	@PostMapping("/login")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginForm loginRequest) {
		System.out.println(loginRequest.getuId());
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getMobileNumber(), loginRequest.getuId()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = jwtProvider.generateJwtToken(authentication);
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(), userDetails.getAuthorities()));
	}

	@PostMapping("/adduser")
	public ResponseEntity<?> registerUser(@RequestBody SignUpForm signUpRequest)
			throws UserRegistrationException {
		String result = userRegistrationService.addUser(signUpRequest);
		return new ResponseEntity<>(new ResponseMessage(result), HttpStatus.OK);

	}

	@GetMapping
	@PreAuthorize("hasRole('TRADER') or hasRole('ADMIN') or hasRole('BROKER') or hasRole('FARMER')")
	public ResponseEntity<Map<String, Object>> getAllUsers() throws UserNotExistsException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.getAllUsers());
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(result);
	}

	@PutMapping("/updateUser")
	@PreAuthorize("hasRole('TRADER') or hasRole('ADMIN') or hasRole('BROKER') or hasRole('FARMER')")
	public ResponseEntity<?> updateUser(@RequestBody User user) throws UserRegistrationException {
		User result = userRegistrationService.updateUser(user);
		return ResponseEntity.status(HttpStatus.CREATED).body(result);

	}

	@PostMapping("/add-roles")
//	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Role> addRoles(@RequestBody Role role) throws UserRegistrationException {
		Role result = userRegistrationService.addRole(role);
		return ResponseEntity.status(HttpStatus.CREATED).body(result);

	}

	@GetMapping("/{mobileNumber}")
	@PreAuthorize("hasRole('TRADER') or hasRole('ADMIN') or hasRole('BROKER') or hasRole('FARMER')")
	public ResponseEntity<Map<String, Object>> getUser(@PathVariable String mobileNumber)
			throws UserNotExistsException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.getUser(mobileNumber));
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(result);
	}

	@DeleteMapping("/{mobileNumber}")
	@PreAuthorize("hasRole('TRADER') or hasRole('ADMIN') or hasRole('BROKER') or hasRole('FARMER')")
	public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable String mobileNumber)
			throws UserNotExistsException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.deleteUser(mobileNumber));
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(result);
	}

	@PutMapping("/update-business-profile")
	@PreAuthorize("hasRole('TRADER') or hasRole('BROKER') or hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> updateBusinessProfile(@RequestBody BusinessProfileDto businessProfileDto)
			throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.addBusinessProfile(businessProfileDto));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@PutMapping("/update-subscription/{mobileNumber}")
	@PreAuthorize("hasRole('TRADER') or hasRole('BROKER') or hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> updateSubscription(@PathVariable String mobileNumber,
			@RequestBody Subscription subscription) throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.updateSubscription(mobileNumber, subscription));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@PutMapping("/add-farmer-products/{mobileNumber}")
	@PreAuthorize("hasRole('FARMER')")
	public ResponseEntity<Map<String, Object>> addProducts(@PathVariable String mobileNumber,
			@RequestBody FarmerProductsDto farmerProductDto) throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.addProducts(mobileNumber, farmerProductDto));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@PutMapping("/addSubscriber/{mobileNumber}")
	@PreAuthorize("hasRole('FARMER') or hasRole('TRADER') or hasRole('BROKER') or hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> addSubscriber(@PathVariable String mobileNumber,
			@RequestBody User subscriber) throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.addSubscriber(mobileNumber, subscriber));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@PutMapping("/removeSubscriber/{mobileNumber}")
	@PreAuthorize("hasRole('FARMER') or hasRole('TRADER') or hasRole('BROKER') or hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> removeSubscriber(@PathVariable String mobileNumber,
			@RequestBody User subscriber) throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.removeSubscriber(mobileNumber, subscriber));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

	@GetMapping("/get-subscribers/{mobileNumber}")
	@PreAuthorize("hasRole('FARMER') or hasRole('TRADER') or hasRole('BROKER') or hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> getSubscribersByMobileNumber(@PathVariable String mobileNumber)
			throws UserRegistrationException {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("HttpStatus", HttpStatus.ACCEPTED);
		result.put("body", userRegistrationService.getSubscribers(mobileNumber));
		return ResponseEntity.status(HttpStatus.CREATED).body(result);
	}

}