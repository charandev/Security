package com.trademan.userservice.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.Location;
import com.trademan.userservice.exception.UnableToDeleteLocationException;

@Service
public interface LocationService {

	public Location addLocation(Location location);

	public List<Location> getAllLocations();

	public String deleteLocation(String displayName) throws UnableToDeleteLocationException;

}
