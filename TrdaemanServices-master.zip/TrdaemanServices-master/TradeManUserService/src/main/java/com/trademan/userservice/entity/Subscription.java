package com.trademan.userservice.entity;

public class Subscription {
	private boolean isSubscribed;
	private SubscriptionPlan subscriptionPlan;
	public boolean isSubscribed() {
		return isSubscribed;
	}
	public void setSubscribed(boolean isSubscribed) {
		this.isSubscribed = isSubscribed;
	}
	public SubscriptionPlan getSubscriptionPlan() {
		return subscriptionPlan;
	}
	public void setSubscriptionPlan(SubscriptionPlan subscriptionPlan) {
		this.subscriptionPlan = subscriptionPlan;
	}
	public Subscription(boolean isSubscribed, SubscriptionPlan subscriptionPlan) {
		super();
		this.isSubscribed = isSubscribed;
		this.subscriptionPlan = subscriptionPlan;
	}
	public Subscription() {
		super();
		// TODO Auto-generated constructor stub
	}

}
