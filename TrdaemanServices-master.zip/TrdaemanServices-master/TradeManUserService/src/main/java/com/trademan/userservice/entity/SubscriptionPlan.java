package com.trademan.userservice.entity;

public enum SubscriptionPlan {

	TRADEMAN_SILVER, TRADEMAN_GOLD, TRADEMAN_DIAMOND, TRADEMAN_PLATINUM;

}
