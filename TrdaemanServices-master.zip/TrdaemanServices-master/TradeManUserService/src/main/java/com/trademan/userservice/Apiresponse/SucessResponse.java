package com.trademan.userservice.Apiresponse;

public class SucessResponse {

	private String message;

	public SucessResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SucessResponse(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
