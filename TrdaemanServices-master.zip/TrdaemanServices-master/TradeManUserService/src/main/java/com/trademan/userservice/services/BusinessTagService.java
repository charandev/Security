package com.trademan.userservice.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trademan.userservice.entity.BusinessTag;
import com.trademan.userservice.exception.UnableToDeleteTagException;

@Service
public interface BusinessTagService {

	public BusinessTag addBusinessTag(BusinessTag businessTag);

	public List<BusinessTag> getAllBusinessTags();

	public String deleteTag(String commodityName) throws UnableToDeleteTagException;
}
