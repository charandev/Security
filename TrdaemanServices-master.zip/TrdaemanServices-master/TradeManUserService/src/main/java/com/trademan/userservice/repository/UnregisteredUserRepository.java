package com.trademan.userservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.trademan.userservice.entity.UnregisteredUser;

@Repository
public interface UnregisteredUserRepository extends MongoRepository<UnregisteredUser, String> {

	public UnregisteredUser findByMobileNumber(String mobileNumber);

}
