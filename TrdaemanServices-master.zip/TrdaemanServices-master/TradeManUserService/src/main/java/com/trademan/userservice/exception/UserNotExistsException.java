package com.trademan.userservice.exception;

public class UserNotExistsException extends UserRegistrationException {

	public UserNotExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotExistsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public UserNotExistsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public UserNotExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UserNotExistsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
