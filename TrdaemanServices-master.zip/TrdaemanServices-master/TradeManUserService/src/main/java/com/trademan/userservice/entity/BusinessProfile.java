package com.trademan.userservice.entity;

public class BusinessProfile {

	private String businessName;
	private String userDesignation;
	private String businessType;

	private Subscription subscription;

	public BusinessProfile() {
	}

	public BusinessProfile(String businessName, String userDesignation, String businessType,
			Subscription subscription) {
		this.businessName = businessName;
		this.userDesignation = userDesignation;
		this.businessType = businessType;
		this.subscription = subscription;
	}

	public String getBusinessName() {
		return businessName;
	}

	public String getBusinessType() {
		return businessType;
	}

	public Subscription getSubscription() {
		return subscription;
	}

	public String getUserDesignation() {
		return userDesignation;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}

	public void setUserDesignation(String userDesignation) {
		this.userDesignation = userDesignation;
	}

}
